<?php
	$array = [5, 4, 3, 2, 1];
	sort($array);
	print_r($array);
?>